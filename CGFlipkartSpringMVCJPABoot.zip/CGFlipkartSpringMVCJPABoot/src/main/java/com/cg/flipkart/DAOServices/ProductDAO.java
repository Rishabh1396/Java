package com.cg.flipkart.DAOServices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.flipkart.beans.Product;

public interface ProductDAO extends JpaRepository<Product, Integer>{

}
