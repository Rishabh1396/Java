package com.cg.flipkart.DAOServices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.flipkart.beans.Bill;

public interface BillDAO extends JpaRepository<Bill, Integer>{

}
