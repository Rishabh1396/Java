package com.cg.flipkart.beans;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

public class Order {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="orderIdGenerator")
	@SequenceGenerator(name="orderIdGenerator",sequenceName="orderId_seq",initialValue=30000)
	private int orderId;
	private LocalDate orderDate;
	
	@OneToMany(mappedBy="order")
	private List<Product> products;
	
	@OneToOne
	private Bill bill;
	
	@ManyToOne
	private Customer customer;
}
