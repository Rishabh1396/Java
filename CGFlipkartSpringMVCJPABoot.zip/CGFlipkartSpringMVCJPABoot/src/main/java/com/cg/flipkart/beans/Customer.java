package com.cg.flipkart.beans;

import java.util.List;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="customerIdGenerator")
	@SequenceGenerator(name="customerIdGenerator",sequenceName="customerId_seq",initialValue=1001)
	private int customerId;
	private String firstName;
	private String lastName;
	private String emailId;
	private String password;
	
	@Embedded
	private Address shippingAddress;
	
	@OneToMany(mappedBy="customer")
	private List<Order> orders;
	
	@OneToMany(mappedBy="customer")
	private List<Bill> bills;
}
