package com.cg.flipkart.beans;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

public class Bill {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="BillIdGenerator")
	@SequenceGenerator(name="BillIDGenerator",sequenceName="billId_seq",initialValue=500000)
	private int billId;
	private float finalPrice;
	
	@OneToOne
	private Order order;
	
	@ManyToOne
	private Customer customer;
}
