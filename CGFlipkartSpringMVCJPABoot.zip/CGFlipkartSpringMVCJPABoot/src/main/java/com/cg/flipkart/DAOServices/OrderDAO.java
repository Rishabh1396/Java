package com.cg.flipkart.DAOServices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.flipkart.beans.Order;

public interface OrderDAO extends JpaRepository<Order, Integer>{

}
