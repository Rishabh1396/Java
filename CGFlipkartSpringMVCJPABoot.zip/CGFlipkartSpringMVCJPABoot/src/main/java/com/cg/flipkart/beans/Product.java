package com.cg.flipkart.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="productIdGenerator")
	@SequenceGenerator(name="productIdGenerator",sequenceName="productId_seq",initialValue=11111)
	private int productId;
	private float price;
	private String productName;
	
	@ManyToOne
	private Order order;
	
}
