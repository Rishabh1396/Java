package com.capgemini.bank.service;

import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.exceptions.BankingServicesDownException;

public class DemandDraftService implements IDemandDraftService {
DemandDraftDAO demandDraftDAO = new DemandDraftDAO();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws BankingServicesDownException {
		// TODO Auto-generated method stub
		try {
			int dd_amount = demandDraft.getDd_amount();
			if(dd_amount<=5000)
				demandDraft.setDd_commission(10);
			else if(dd_amount>5000 && dd_amount<=10000)
				demandDraft.setDd_commission(41);
			else if(dd_amount>10000 && dd_amount<=100000)
				demandDraft.setDd_commission(51);
			else if(dd_amount>100000 && dd_amount<=500000)
				demandDraft.setDd_commission(306);
			return demandDraftDAO.addDemandDraftDetails(demandDraft);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BankingServicesDownException("Server Down.");
		}
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

}
