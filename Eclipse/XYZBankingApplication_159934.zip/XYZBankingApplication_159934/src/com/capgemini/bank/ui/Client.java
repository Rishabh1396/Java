package com.capgemini.bank.ui;

import java.sql.SQLException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingServicesDownException;
import com.capgemini.bank.service.DemandDraftService;

public class Client {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		try {
			int ch=0;
			DemandDraftService demandDraftService = new DemandDraftService();
			while(ch!=2){
				System.out.println("1.Enter Demand Draft Details\n2.Exit");
				Scanner sc = new Scanner(System.in);
				ch = Integer.parseInt(sc.next());
				if(ch!=2){
					switch (ch) {
					case 1:
						System.out.println("Enter the name of the customer: ");
						String customer_name = sc.next();
						String phone_number="";
						while(phone_number.length()!=10 || phone_number.isEmpty()){
							System.out.println("Enter customer phone number: ");
							phone_number = sc.next();
							if(phone_number.length()!=10){
								System.err.println("Phone Number must be of 10 digits.");
							}
						}
						System.out.println("In favor of: ");
						String in_favor_of = sc.next();
						System.out.println("Enter Demand Draft amount (in Rs): ");
						int dd_amount = sc.nextInt();
						System.out.println("Enter Remarks: ");
						Scanner sc2 = new Scanner(System.in).useDelimiter("\\n*");
						String dd_description = sc2.next();
						/*Scanner sc2 = new Scanner(System.in);
						String dd_description = sc2.nextLine();*/
						sc2.close();
						DemandDraft demandDraft = new DemandDraft(dd_amount, customer_name, in_favor_of, phone_number, dd_description);
						System.out.println("Your Demand Draft request has been successfully registered along with the "+demandDraftService.addDemandDraftDetails(demandDraft));
						break;

					default:
						break;
					}
					sc.close();
				}
			}
		} catch (BankingServicesDownException e) {
			// TODO: handle exception
			System.err.println(e.getMessage());
		}catch (NoSuchElementException e) {
			// TODO: handle exception
		}
	}
}
