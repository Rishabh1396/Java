package com.capgemini.bank.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;

public class DemandDraftDAOTest {
	//DemandDraft demandDraft = new DemandDraft(transaction_id, dd_amount, dd_commission, customer_name, in_favor_of, phone_number, date_of_transaction, dd_description)
	
	@BeforeClass
	public static void setUpTestEnv() {
		
	}
	@Before
	public void setUpTestData() {
		
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	@After
	public void tearDownTestData() {
		
	}
	
	@AfterClass
	public static void destroyUpTestEnv() {
		
	}

}
