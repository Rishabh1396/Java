package com.cg.mobile.daoservices;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.beans.Mobiles;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.exceptions.PurchaseServicesDownException;

public interface PurchaseDao {
	int save(PurchaseDetails purchaseDetails)throws SQLException;
	int updateMobileQuantity(int mobileid) throws SQLException;
	ArrayList<Mobiles> getAllmobileDetails() throws SQLException;
	void deleteMobileDetails(int mobileId) throws SQLException;
	ArrayList<Mobiles> getMobileDetails(int minRange,int maxRange) throws SQLException;
	

}
