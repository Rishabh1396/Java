package com.cg.mobile.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.beans.Mobiles;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.util.ConnectionProvider;


public class PurchaseDaoImp implements PurchaseDao {
	private Connection conn=ConnectionProvider.getDBConnection();

	@Override
	public int save(PurchaseDetails purchaseDetails) throws SQLException {
		try{
			conn.setAutoCommit(false);
			
		PreparedStatement pstmt1 = conn.prepareStatement("INSERT INTO PURCHASEDETAILS( purchaseid,cname,mailid,phoneno,purchasedate,mobileid)VALUES(PURCHASE_ID_SEQ.nextval,?,?,?,TO_DATE(sysdate,'DD-MM-YYYY'),?)");
		pstmt1.setString(1,purchaseDetails.getCname());
		pstmt1.setString(2,purchaseDetails.getMailid());
		pstmt1.setString(3,purchaseDetails.getPhoneno());
		pstmt1.setInt(4,purchaseDetails.getMobileid());
		pstmt1.executeUpdate();
		conn.commit();
		PreparedStatement pstmt2 = conn.prepareStatement("select * from PURCHASEDETAILS where purchaseid=(select max(purchaseid)from PURCHASEDETAILS)");
		ResultSet rs = pstmt2.executeQuery();
		rs.next();
		return rs.getInt("purchaseid");
	}catch(SQLException e){
		e.printStackTrace();
		conn.rollback();
		throw e;
	}finally{
		conn.setAutoCommit(true);
	}
	}

	@Override
	public int updateMobileQuantity(int mobileid) throws SQLException {
		try{
			conn.setAutoCommit(false);
			
		PreparedStatement pstmt1 = conn.prepareStatement("select * from mobiles where mobileid=?");
		pstmt1.setInt(1,mobileid);
		ResultSet mobileRS = pstmt1.executeQuery();
		int quantity=Integer.parseInt(mobileRS.getString("quantity"))-1;
		PreparedStatement pstmt2 = conn.prepareStatement("update mobiles set quantity=? where mobileid=?");
		pstmt2.setString(1,Integer.toString(quantity));
		pstmt2.setInt(2,mobileid);
		conn.commit();
		PreparedStatement pstmt3 = conn.prepareStatement("select * from mobiles where mobileid=?");
		pstmt3.setInt(1,mobileid);
		ResultSet rs = pstmt3.executeQuery();
		rs.next();
		return rs.getInt("quantity");
	}catch(SQLException e){
		e.printStackTrace();
		conn.rollback();
		throw e;
	}finally{
		conn.setAutoCommit(true);
	}
	}

	@Override
	public ArrayList<Mobiles> getAllmobileDetails() throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("Select * from mobiles");
		ResultSet mobileRS = pstmt1.executeQuery();
		
		ArrayList<Mobiles> mobile = new ArrayList<>();
		while(mobileRS.next()){
			int mobileid=mobileRS.getInt("mobileid");
			int price=mobileRS.getInt("price");
			String name=mobileRS.getString("name");
			String quantity=mobileRS.getString("quantity");
			Mobiles mobile1=new Mobiles(mobileid, price, name, quantity);
			mobile.add(mobile1);
		}
		return mobile;
	}

	@Override
	public void deleteMobileDetails(int mobileId) throws SQLException {
		PreparedStatement pstmt1=conn.prepareStatement("delete from mobiles where mobileid=? cascade constraints");
		pstmt1.setInt(1, mobileId);
		pstmt1.executeUpdate();
		
	}

	@Override
	public ArrayList<Mobiles> getMobileDetails(int minRange, int maxRange)
			throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("Select * from mobiles where price in");   //Query daalni baki h
		ResultSet mobileRS = pstmt1.executeQuery();
		
		ArrayList<Mobiles> mobile = new ArrayList<>();
		while(mobileRS.next()){
			int mobileid=mobileRS.getInt("mobileid");
			int price=mobileRS.getInt("price");
			String name=mobileRS.getString("name");
			String quantity=mobileRS.getString("quantity");
			Mobiles mobile1=new Mobiles(mobileid, price, name, quantity);
			mobile.add(mobile1);
		}
		return mobile;
	}




}
