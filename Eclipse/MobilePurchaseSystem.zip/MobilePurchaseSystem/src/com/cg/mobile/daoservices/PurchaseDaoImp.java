package com.cg.mobile.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.beans.Mobiles;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.exceptions.PurchaseServicesDownException;
import com.cg.mobile.util.ConnectionProvider;


public class PurchaseDaoImp implements PurchaseDao {
	private Connection conn=ConnectionProvider.getDBConnection();

	@Override
	public int save(PurchaseDetails purchaseDetails) throws SQLException {
		try{
			conn.setAutoCommit(false);
			
		PreparedStatement pstmt1 = conn.prepareStatement("INSERT INTO PURCHASEDETAILS( purchaseid,cname,mailid,phoneno,purchasedate,mobileid)VALUES(PURCHASE_ID_SEQ.nextval,?,?,?,TO_DATE(sysdate,'DD-MM-YYYY'),?)");
		pstmt1.setString(1,purchaseDetails.getCname());
		pstmt1.setString(2,purchaseDetails.getMailid());
		pstmt1.setString(3,purchaseDetails.getPhoneno());
		pstmt1.setInt(4,purchaseDetails.getMobileid());
		pstmt1.executeQuery();
		conn.commit();
		PreparedStatement pstmt2 = conn.prepareStatement("select * from PURCHASEDETAILS where purchaseid=(select max(purchaseid)from PURCHASEDETAILS)");
		ResultSet rs = pstmt2.executeQuery();
		rs.next();
		return rs.getInt("purchaseid");
	}catch(SQLException e){
		e.printStackTrace();
		conn.rollback();
		throw e;
	}finally{
		conn.setAutoCommit(true);
	}
	}

	@Override
	public int updateMobileQuantity(int mobileid) throws SQLException {
		try{
			conn.setAutoCommit(false);
			
		PreparedStatement pstmt1 = conn.prepareStatement("update mobiles set mobilequantity=");
		pstmt1.setString(1,purchaseDetails.getCname());
		pstmt1.setString(2,purchaseDetails.getMailid());
		pstmt1.setString(3,purchaseDetails.getPhoneno());
		pstmt1.setInt(4,purchaseDetails.getMobileid());
		pstmt1.executeQuery();
		conn.commit();
		PreparedStatement pstmt2 = conn.prepareStatement("select * from PURCHASEDETAILS where purchaseid=(select max(purchaseid)from PURCHASEDETAILS)");
		ResultSet rs = pstmt2.executeQuery();
		rs.next();
		return rs.getInt("purchaseid");
	}catch(SQLException e){
		e.printStackTrace();
		conn.rollback();
		throw e;
	}finally{
		conn.setAutoCommit(true);
	}
	}

	@Override
	public ArrayList<Mobiles> getAllmobileDetails() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteMobileDetails(int mobileId) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Mobiles> getMobileDetails(int minRange, int maxRange)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}




}
