package com.cg.mobile.client;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.exceptions.PurchaseServicesDownException;
import com.cg.mobile.services.PurchaseServices;
import com.cg.mobile.services.PurchaseServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		try {
			PurchaseServices purchaseServices=new PurchaseServicesImpl();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter your choice from below menuchart ");
			System.out.println("a) Insert the customer and purchase details.\n b)	Update the mobile quantity in mobiles table, once mobile is purchased by a customer.\nc)	View details of all mobiles available in the shop.\nd) Delete a mobile details based on mobile id.\ne)	Search mobiles based on price range.\nf)	Insert and search mobile service functionalities");
			char userChoice = sc.next().charAt(0);
			switch (Character.toUpperCase(userChoice)){
			case 'A':
			{
				System.out.println("\nEnter the customer name:");
				String cname = sc.next();
				System.out.println("Enter the mailid:");
				String mailid = sc.next();
				System.out.println("\nEnter the phoneno:");
				String phoneno = sc.next();
				System.out.println("Enter the purchasedate:");
				String purchasedate = sc.next();
				System.out.println("Enter the mobileid:");
				int mobileid = sc.nextInt();
				//sc.nextLine();
				PurchaseDetails purchaseDetails=new PurchaseDetails(mobileid,cname, mailid, phoneno, purchasedate);
				purchaseServices.acceptPurchaseDetails(purchaseDetails);
				System.out.println("Thank you for shopping "+cname);
				
				break;
			}
			case 'B':
			{
				System.out.println("Enter the mobileid:");
				int mobileid = sc.nextInt();
				purchaseServices.updateMobileQuantity(mobileid);
				
				break;
			}
			case 'C':
			{
				
			}
			case 'D':
			{
				
			}
			case 'E':
			{
				
			}
			case 'F':
			{
				
			}
			default:
				System.out.println("Enter a valid choice.");
			}
		} catch (PurchaseServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}
}

