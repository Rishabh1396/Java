package com.cg.mobile.client;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.mobile.beans.Mobiles;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.exceptions.PurchaseServicesDownException;
import com.cg.mobile.services.PurchaseServices;
import com.cg.mobile.services.PurchaseServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		try {
			PurchaseServices purchaseServices=new PurchaseServicesImpl();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter your choice from below menuchart ");
			System.out.println("a) Insert the customer and purchase details.\n b)	Update the mobile quantity in mobiles table, once mobile is purchased by a customer.\nc)	View details of all mobiles available in the shop.\nd) Delete a mobile details based on mobile id.\ne)	Search mobiles based on price range.");
			char userChoice = sc.next().charAt(0);
			switch (Character.toUpperCase(userChoice)){
			case 'A':
			{	String cname="";
			while(cname.isEmpty()||cname.length()>20||!Character.isUpperCase(cname.charAt(0))){
				System.out.println("\nEnter the customer name:");
				cname = sc.next();
				if(cname.isEmpty()||cname.length()>20||!Character.isUpperCase(cname.charAt(0))){
					System.err.println("Enter valid name!");
				}
			}
			String mailid="";
			while(!isValid(mailid)){
				System.out.println("Enter the mailid:");
				mailid = sc.next();
				if(!isValid(mailid))
					System.err.println("Enter valid Email!");
			}
			System.out.println("\nEnter the phoneno:");     //Not yet validated
			String phoneno = sc.next();
			System.out.println("Enter the purchasedate:");		//Not yet validated
			String purchasedate = sc.next();
			System.out.println("Enter the mobileid:");			//Not yet validated
			int mobileid = sc.nextInt();
			//sc.nextLine();
			PurchaseDetails purchaseDetails=new PurchaseDetails(mobileid,cname, mailid, phoneno, purchasedate);
			purchaseServices.acceptPurchaseDetails(purchaseDetails);
			System.out.println("Thank you for shopping "+cname);

			break;
			}
			case 'B':
			{
				System.out.println("Enter the mobileid:");
				int mobileid = sc.nextInt();
				purchaseServices.updateMobileQuantity(mobileid);

				break;
			}
			case 'C':
			{
				ArrayList<Mobiles>mobile = purchaseServices.getAllmobileDetails();
				int i=0;
				while(i<mobile.size()){
					printDetails(mobile.get(i));
					i++;
				}
				break;
			}
			case 'D':
			{

				System.out.println("\nEnter the mobile ID to be deleted:");
				int mobileId = sc.nextInt();
				purchaseServices.deleteMobileDetails(mobileId);
				break;
			}
			case 'E':
			{
				System.out.println("\nEnter the Min value:");
				int minRange = sc.nextInt();
				System.out.println("Enter the Max value:");
				int maxRange = sc.nextInt();
				ArrayList<Mobiles>mobile = purchaseServices.getMobileDetails(minRange, maxRange);
				int i=0;
				while(i<mobile.size()){
					printDetails(mobile.get(i));
					i++;
				}
				break;

			}
			default:
				System.out.println("Enter a valid choice.");
			}
			sc.close();
		} catch (PurchaseServicesDownException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.err.println(e.getMessage());
		}


	}

	public static void printDetails(Mobiles mobiles){
		System.out.println("Mobile ID: " + mobiles.getMobileId());
		System.out.println("Price:" + mobiles.getPrice());
		System.out.println("Quantity: " + mobiles.getQuantity());
		System.out.println("Name: " + mobiles.getName());

	}
	public static boolean isValid(String email) 
	{ 
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
				"[a-zA-Z0-9_+&*-]+)*@" + 
				"(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
				"A-Z]{2,7}$"; 

		Pattern pat = Pattern.compile(emailRegex); 
		if (email == null) 
			return false; 
		return pat.matcher(email).matches(); 
	}
}

