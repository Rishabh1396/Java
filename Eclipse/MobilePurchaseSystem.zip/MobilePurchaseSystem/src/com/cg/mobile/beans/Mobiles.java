package com.cg.mobile.beans;

public class Mobiles {
	private int mobileId, price;
	private String name,quantity;
	
	public Mobiles() {
	}

	public Mobiles(int mobileId, int price, String name, String quantity) {
		super();
		this.mobileId = mobileId;
		this.price = price;
		this.name = name;
		this.quantity = quantity;
	}

	public int getMobileId() {
		return mobileId;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

}