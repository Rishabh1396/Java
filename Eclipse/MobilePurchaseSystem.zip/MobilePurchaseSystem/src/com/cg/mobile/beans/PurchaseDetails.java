package com.cg.mobile.beans;

public class PurchaseDetails {
	private int purchaseid,mobileid;
	private String cname,mailid,phoneno,purchasedate;
	
	
	public PurchaseDetails() {
	}

	
	
	public PurchaseDetails(int mobileid, String cname, String mailid,
			String phoneno, String purchasedate) {
		super();
		this.mobileid = mobileid;
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.purchasedate = purchasedate;
	}



	public PurchaseDetails(String cname, String mailid, String phoneno,
			String purchasedate) {
		super();
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.purchasedate = purchasedate;
	}

	public int getPurchaseid() {
		return purchaseid;
	}

	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public String getPurchasedate() {
		return purchasedate;
	}

	public void setPurchasedate(String purchasedate) {
		this.purchasedate = purchasedate;
	}



	public int getMobileid() {
		return mobileid;
	}



	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}

	
	
	
}
