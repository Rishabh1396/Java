package com.cg.mobile.services;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.mobile.beans.Mobiles;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.exceptions.PurchaseServicesDownException;

public interface PurchaseServices {
	int acceptPurchaseDetails(PurchaseDetails purchaseDetails) throws PurchaseServicesDownException;
	int updateMobileQuantity(int mobileid) throws PurchaseServicesDownException;
	ArrayList<Mobiles> getAllmobileDetails() throws PurchaseServicesDownException;
	void deleteMobileDetails(int mobileId) throws PurchaseServicesDownException;
	ArrayList<Mobiles> getMobileDetails(int minRange,int maxRange) throws PurchaseServicesDownException;
}
