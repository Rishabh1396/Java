package com.cg.mobile.services;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.beans.Mobiles;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.daoservices.PurchaseDao;
import com.cg.mobile.daoservices.PurchaseDaoImp;
import com.cg.mobile.exceptions.PurchaseServicesDownException;

public class PurchaseServicesImpl implements PurchaseServices {
	PurchaseDao purchaseDao=new PurchaseDaoImp();

	@Override
	public int acceptPurchaseDetails(PurchaseDetails purchaseDetails)
			throws PurchaseServicesDownException {
		try {
			int purchaseid = purchaseDao.save(purchaseDetails);
			return purchaseid;
		} catch (SQLException e) {
			//e.printStackTrace();
			throw new PurchaseServicesDownException("Service Down!");
		}
	}

	@Override
	public int updateMobileQuantity(int mobileid)
			throws PurchaseServicesDownException {
		try {
			int mobilequantity=purchaseDao.updateMobileQuantity(mobileid);
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new PurchaseServicesDownException("Service Down!");
		}
	}

	@Override
	public ArrayList<Mobiles> getAllmobileDetails()
			throws PurchaseServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteMobileDetails(int mobileId)
			throws PurchaseServicesDownException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Mobiles> getMobileDetails(int minRange, int maxRange)
			throws PurchaseServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

}