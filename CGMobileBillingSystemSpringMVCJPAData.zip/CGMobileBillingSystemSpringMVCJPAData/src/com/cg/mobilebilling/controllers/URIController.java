package com.cg.mobilebilling.controllers;

import org.springframework.web.bind.annotation.RequestMapping;

public class URIController {

	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
}
