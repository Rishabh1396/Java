package com.cg.mobilebilling.controllers;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;

public class URIController {

	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/newCustomer")
	public String getNewCustomerPage() {
		return "newCustomerPage";
	}
	@RequestMapping("/plans")
	public String getPlansPage() {
		return "plansPage";
	}
	@RequestMapping("/planDetails")
	public String getPlanDetailsPage() {
		return "planDetailsPage";
	}
	
	@RequestMapping("/viewBill")
	public String getViewBillPage() {
		return "viewBillPage";
	}
	@RequestMapping("/generateBill")
	public String getGenerateBillPage() {
		return "generateBillPage";
	}
	@RequestMapping("/managePostpaidAccount")
	public String getManagePostpaidAccountPage() {
		return "managePostpaidAccountPage";
	}
	@RequestMapping("/viewPostpaidAccount")
	public String getViewPostpaidAccountPage() {
		return "viewPostpaidAccountPage";
	}
	
	@RequestMapping("/plansAddedSuccessfully")
	public String getplansAddedSuccessfullyPage() {
		return "plansAddedSuccessfullyPage";
	}
	
	@ModelAttribute
	public Customer getCustomer() {
		return new Customer();
	}
	
	@ModelAttribute
	public Plan getPlan() {
		return new Plan();
	}
	
	@ModelAttribute
	public PostpaidAccount getPostpaidAccount() {
		return new PostpaidAccount();
	}
}
