package com.cg.mobilebilling.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.daoservices.PlanDAO;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class PlanController {
	@Autowired
	private BillingServices billingServices;
	
	@RequestMapping("/addPlan")
	public ModelAndView addPlanAction(@ModelAttribute Plan plan) throws BillingServicesDownException{
		plan = billingServices.addPlanDetails(plan);
		
		return new ModelAndView("addPlanPage","plan",plan);
	}
	
	@RequestMapping("/plansAddedSuccessfully")
	public ModelAndView successfullyAddedPlansAction() throws BillingServicesDownException{
		
		return new ModelAndView("plansAddedSuccessfullyPage","plans",plans);
	}
	
	@RequestMapping("/savePlan")
	public ModelAndView savePlan(@ModelAttribute PostpaidAccount postpaidAccount) throws BillingServicesDownException{
		postpaidAccount=billingServicesImpl.
		return new ModelAndView("planRegistered","postpaidAccount",postpaidAccount);
	}
	
	}

