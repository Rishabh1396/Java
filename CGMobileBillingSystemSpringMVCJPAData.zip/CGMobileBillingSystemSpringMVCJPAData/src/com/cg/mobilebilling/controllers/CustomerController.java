package com.cg.mobilebilling.controllers;

import javax.validation.Valid;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


public class CustomerController {

	@RequestMapping("/registerAssociate")
	public ModelAndView registerAssociateAction(@Valid @ModelAttribute Associate associate, BindingResult result)throws PayrollServicesDownException{
		
		/*if(result.hasErrors())
			return new ModelAndView("RegistrationPage");
		
		associate = payrollServices.acceptAssociateDetails(associate);
		return new ModelAndView("registrationSuccessPage", "associate", associate);*/
	}
}
