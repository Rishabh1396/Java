package com.cg.mobilebilling.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillDAO;
import com.cg.mobilebilling.daoservices.CustomerDAO;
import com.cg.mobilebilling.daoservices.PlanDAO;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;

@Component(value="billingServices")
public class BillingServicesImpl implements BillingServices {

	@Autowired
	private BillDAO billDAO;
	@Autowired
	private CustomerDAO customerDAO;
	@Autowired
	private PlanDAO planDAO;
	@Autowired
	private PostpaidAccountDAO postpaidAccountDAO;
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer)
			throws BillingServicesDownException {
		return customerDAO.save(customer);
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).get();
		if(customer==null)
			throw new CustomerDetailsNotFoundException();
		Plan plan=planDAO.findById(planID).get();
		if(plan==null)
			throw new PlanDetailsNotFoundException();
		PostpaidAccount postpaidAccount=new PostpaidAccount(plan, customer);
		postpaidAccountDAO.save(postpaidAccount);
		return 0;
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).get();
		if(customer==null)
			throw new CustomerDetailsNotFoundException();
		else
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return customerDAO.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		//PostpaidAccount postpaidAccount=postpaidAccountDAO Queryyyyyyyyyyyyyy in postpaidDAO
		return null;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("No customer with this customerID exists."));
		///query in postpaidDAO
		return null;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("No customer with this customerID exists."));
		PostpaidAccount postpaidAccount=postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("No PostPid account exists for this number."));
		//query in billDAO
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("No customer with this customerID exists."));
		PostpaidAccount postpaidAccount=postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("No PostPid account exists for this number."));
		//query in BillDAO
		return null;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("No customer with this customerID exists."));
		PostpaidAccount postpaidAccount=postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("No PostPid account exists for this number."));
		Plan plan=planDAO.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("No plan with such planID exists."));
		postpaidAccount.setPlan(plan);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("No customer with this customerID exists."));
		PostpaidAccount postpaidAccount=postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("No PostPid account exists for this number."));
		postpaidAccountDAO.deleteById(mobileNo);
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("No customer with this customerID exists."));
		customerDAO.deleteById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("No customer with this customerID exists."));
		PostpaidAccount postpaidAccount=postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("No PostPid account exists for this number."));
		return postpaidAccount.getPlan();
	}

	@Override
	public Plan addPlanDetails(Plan plan) {
	 plan = planDAO.save(plan);
		return plan;
	}



}