package com.cg.mobilebilling.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class registrationStepDefinition {

@Given("^User is on registrationPage$")
public void user_is_on_registrationPage() throws Throwable {
    
}

@When("^User enter his correct credentials and click on submit button of registrationPage$")
public void user_enter_his_correct_credentials_and_click_on_submit_button_of_registrationPage() throws Throwable {
    
}

@Then("^User is redirected to registration page and message gets displayed$")
public void user_is_redirected_to_registration_page_and_message_gets_displayed() throws Throwable {
  
}

@Given("^User is on registration Page$")
public void user_is_on_registration_Page() throws Throwable {
  
}

@When("^User click on home page button of registrationPage$")
public void user_click_on_home_page_button_of_registrationPage() throws Throwable {
   
}

@Then("^User is redirected to home page from registrationPage$")
public void user_is_redirected_to_home_page_from_registrationPage() throws Throwable {
  
}

}
