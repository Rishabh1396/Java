package com.cg.mobilebilling.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetPlanAllDdetailsStepDefinition {
	
	@Given("^User is on getPlanAllDetailsPage Page$")
	public void user_is_on_getPlanAllDetailsPage_Page() throws Throwable {
	  
	}

	@When("^User click on home page button of getPlanAllDetailsPage$")
	public void user_click_on_home_page_button_of_getPlanAllDetailsPage() throws Throwable {
	   
	}

	@Then("^User is redirected to home page from getPlanAllDetailsPage$")
	public void user_is_redirected_to_home_page_from_getPlanAllDetailsPage() throws Throwable {
	    
	}

}
