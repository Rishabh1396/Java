package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.AddPlanPage;
import com.cg.mobilebilling.pagebeans.GenerateMonthlyMobileBill;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GenerateMonthlyMobileBillStepDefinition {

	private WebDriver driver;
	private GenerateMonthlyMobileBill generateMonthlyMobileBill;
	
	@Given("^User is on generateMonthlyMobileBillPage Page$")
	public void user_is_on_generateMonthlyMobileBillPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/addPlans");
		
		generateMonthlyMobileBill=PageFactory.initElements(driver, GenerateMonthlyMobileBill.class);
	}

	@When("^User enter his correct credentials and click on submit button$")
	public void user_enter_his_correct_credentials_and_click_on_submit_button() throws Throwable {
		generateMonthlyMobileBill.setCustomerID(customerID);
		generateMonthlyMobileBill.setMobileNo(mobileNo);
		generateMonthlyMobileBill.setNoOfLocalSMS(noOfLocalSMS);
		generateMonthlyMobileBill.setNoOfStdSMS(noOfStdSMS);
		generateMonthlyMobileBill.setNoOfLocalCalls(noOfLocalCalls);
		generateMonthlyMobileBill.setNoOfStdCalls(noOfStdCalls);
		generateMonthlyMobileBill.setInternetDataUsageUnits(internetDataUsageUnits);
		generateMonthlyMobileBill.setBillMonth(billMonth);
		generateMonthlyMobileBill.clickSubmit();
	}

	@Then("^User is redirected to generateMonthlyMobileBillPage page and message gets displayed$")
	public void user_is_redirected_to_generateMonthlyMobileBillPage_page_and_message_gets_displayed() throws Throwable {
		
	}

	@When("^User click on home page button of generateMonthlyMobileBillPage$")
	public void user_click_on_home_page_button_of_generateMonthlyMobileBillPage() throws Throwable {
		generateMonthlyMobileBill.clickHomeButton();
	}

	@Then("^User is redirected to home page form generateMonthlyMobileBillPage$")
	public void user_is_redirected_to_home_page_form_generateMonthlyMobileBillPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Mobile Billing";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
}
