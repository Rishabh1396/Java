package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class OpenPostpaidMobileAccount {

	@FindBy(how=How.ID,id="customerID")
	private WebElement customerID;
	
	@FindBy(how=How.NAME,name="planID")
	private WebElement planID;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/table/tbody/tr[3]/td/input")
	private WebElement submitButton;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/div/form/table/tbody/tr/td/input")
	private WebElement homePageButton;

	@FindBy(how=How.XPATH,xpath="/html/body/div[2]")
	private WebElement message; 
	
	public OpenPostpaidMobileAccount() {
		super();
	}

	public String getCustomerID() {
		return customerID.getAttribute("value");
	}

	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}

	public String getPlanID() {
		return planID.getAttribute("value");
	}

	public void setPlanID(String planID) {
		this.planID.sendKeys(planID);
	}
	
	public String getMessage() {
		return message.getText();
	}

	public void clickSubmit() {
		submitButton.click();
	}
	
	public void clickHomePage() {
		homePageButton.click();
	}
}
