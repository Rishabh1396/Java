package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.AddPlanPage;
import com.cg.mobilebilling.pagebeans.ChangePlan;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ChangePlanStepDefinition {

	private WebDriver driver;
	private ChangePlan changePlan;
	
	
	@Given("^User is on changePlanPage Page$")
	public void user_is_on_changePlanPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/changePlan");
		
		changePlan=PageFactory.initElements(driver, ChangePlan.class);
	}

	@When("^User enter his correct credentials and click on change plan button$")
	public void user_enter_his_correct_credentials_and_click_on_change_plan_button() throws Throwable {
	  changePlan.setCustomerID("20023");
	  changePlan.setMobileNo("999999999");
	  changePlan.setPlanID("1001");
	  changePlan.clickSubmit();
	}

	@Then("^User is redirected to changePlanPage page and message gets displayed$")
	public void user_is_redirected_to_changePlanPage_page_and_message_gets_displayed() throws Throwable {
		String actualMessage=changePlan.getMessage();
		String expectedMessage="Your plan is successfully changed";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}
	
	@When("^User click on home page button of changePlanPage$")
	public void user_click_on_home_page_button_of_changePlanPage() throws Throwable {

	}

	@Then("^User is redirected to home page from changePlanPage$")
	public void user_is_redirected_to_home_page_from_changePlanPage() throws Throwable {

	}
}
