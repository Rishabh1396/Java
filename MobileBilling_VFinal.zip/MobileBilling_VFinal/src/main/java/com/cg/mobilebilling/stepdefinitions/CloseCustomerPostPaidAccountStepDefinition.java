package com.cg.mobilebilling.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CloseCustomerPostPaidAccountStepDefinition {
	
	@Given("^User is on closeCustomerPostPaidAccountPage Page$")
	public void user_is_on_closeCustomerPostPaidAccountPage_Page() throws Throwable {

	}

	@When("^User enter his correct credentials and click on delete postpaid account button$")
	public void user_enter_his_correct_credentials_and_click_on_delete_postpaid_account_button() throws Throwable {

	}

	@Then("^User is redirected to closeCustomerPostPaidAccountPage page and message gets displayed$")
	public void user_is_redirected_to_closeCustomerPostPaidAccountPage_page_and_message_gets_displayed() throws Throwable {

	}

	@When("^User click on home page button of closeCustomerPostPaidAccountPage$")
	public void user_click_on_home_page_button_of_closeCustomerPostPaidAccountPage() throws Throwable {

	}

	@Then("^User is redirected to home page from closeCustomerPostPaidAccountPage$")
	public void user_is_redirected_to_home_page_from_closeCustomerPostPaidAccountPage() throws Throwable {

	}


}
