package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AddPlanPage {

	@FindBy(how=How.ID,id="monthlyRental")
	private WebElement monthlyRental;
	
	@FindBy(how=How.ID,id="freeLocalCalls")
	private WebElement freeLocalCalls;
	
	@FindBy(how=How.ID,id="freeStdCalls")
	private WebElement freeStdCalls;
	
	@FindBy(how=How.ID,id="freeLocalSMS")
	private WebElement freeLocalSMS;
	
	@FindBy(how=How.ID,id="freeStdSMS")
	private WebElement freeStdSMS;
	
	@FindBy(how=How.ID,id="freeInternetDataUsageUnits")
	private WebElement freeInternetDataUsageUnits;
	
	@FindBy(how=How.ID,id="localCallRate")
	private WebElement localCallRate;
	
	@FindBy(how=How.ID,id="stdCallRate")
	private WebElement stdCallRate;
	
	@FindBy(how=How.ID,id="localSMSRate")
	private WebElement localSMSRate;
	
	@FindBy(how=How.ID,id="stdSMSRate")
	private WebElement stdSMSRate;
	
	@FindBy(how=How.ID,id="internetDataUsageRate")
	private WebElement internetDataUsageRate;
	
	@FindBy(how=How.ID,id="planCircle")
	private WebElement planCircle;
	
	@FindBy(how=How.ID,id="planName")
	private WebElement planName;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"plan\"]/input")
	private WebElement button1;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/div/form/table/tbody/tr/td/input")
	private WebElement button2;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]")
	private WebElement addPlanMessage;

	public AddPlanPage() {
		super();
	}
	
	public void clickSubmit() {
		button1.submit();
	}
	
	public void clickHomePage() {
		button2.submit();
	}

	public String getMonthlyRental() {
		return monthlyRental.getAttribute("value");
	}

	public void setMonthlyRental(String monthlyRental) {
		this.monthlyRental.clear();
		this.monthlyRental.sendKeys(monthlyRental);
	}

	public String getFreeLocalCalls() {
		return freeLocalCalls.getAttribute("value");
	}

	public void setFreeLocalCalls(String freeLocalCalls) {
		this.freeLocalCalls.sendKeys(freeLocalCalls);
	}

	public String getFreeStdCalls() {
		return freeStdCalls.getAttribute("value");
	}

	public void setFreeStdCalls(String freeStdCalls) {
		this.freeStdCalls.sendKeys(freeStdCalls);
	}

	public String getFreeLocalSMS() {
		return freeLocalSMS.getAttribute("value");
	}

	public void setFreeLocalSMS(String freeLocalSMS) {
		this.freeLocalSMS.sendKeys(freeLocalSMS);
	}

	public String getFreeStdSMS() {
		return freeStdSMS.getAttribute("value");
	}

	public void setFreeStdSMS(String freeStdSMS) {
		this.freeStdSMS.sendKeys(freeStdSMS);
	}

	public String getFreeInternetDataUsageUnits() {
		return freeInternetDataUsageUnits.getAttribute("value");
	}

	public void setFreeInternetDataUsageUnits(String freeInternetDataUsageUnits) {
		this.freeInternetDataUsageUnits.sendKeys(freeInternetDataUsageUnits);
	}

	public String getLocalCallRate() {
		return localCallRate.getAttribute("value");
	}

	public void setLocalCallRate(String localCallRate) {
		this.localCallRate.clear();
		this.localCallRate.sendKeys(localCallRate);
	}

	public String getStdCallRate() {
		return stdCallRate.getAttribute("value");
	}

	public void setStdCallRate(String stdCallRate) {
		this.stdCallRate.clear();
		this.stdCallRate.sendKeys(stdCallRate);
	}

	public String getLocalSMSRate() {
		return localSMSRate.getAttribute("value");
	}

	public void setLocalSMSRate(String localSMSRate) {
		this.localSMSRate.clear();
		this.localSMSRate.sendKeys(localSMSRate);
	}

	public String getStdSMSRate() {
		return stdSMSRate.getAttribute("value");
	}

	public void setStdSMSRate(String stdSMSRate) {
		this.stdSMSRate.clear();
		this.stdSMSRate.sendKeys(stdSMSRate);
	}

	public String getInternetDataUsageRate() {
		return internetDataUsageRate.getAttribute("value");
	}

	public void setInternetDataUsageRate(String internetDataUsageRate) {
		this.internetDataUsageRate.clear();
		this.internetDataUsageRate.sendKeys(internetDataUsageRate);
	}

	public String getPlanCircle() {
		return planCircle.getAttribute("value");
	}

	public void setPlanCircle(String planCircle) {
		this.planCircle.sendKeys(planCircle);
	}

	public String getPlanName() {
		return planName.getAttribute("value");
	}

	public void setPlanName(String planName) {
		this.planName.sendKeys(planName);
	}

	public String getAddPlanMessage() {
		return addPlanMessage.getText();
	}


}
