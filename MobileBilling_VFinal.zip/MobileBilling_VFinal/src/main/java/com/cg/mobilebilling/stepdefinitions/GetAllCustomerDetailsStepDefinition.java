package com.cg.mobilebilling.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetAllCustomerDetailsStepDefinition {
	
	@Given("^User is on getAllCustomerDetailsPage Page$")
	public void user_is_on_getAllCustomerDetailsPage_Page() throws Throwable {

	}

	@When("^User click on home page button of getAllCustomerDetailsPage$")
	public void user_click_on_home_page_button_of_getAllCustomerDetailsPage() throws Throwable {

	}

	@Then("^User is redirected to home page from getAllCustomerDetailsPage$")
	public void user_is_redirected_to_home_page_from_getAllCustomerDetailsPage() throws Throwable {

	}




}
